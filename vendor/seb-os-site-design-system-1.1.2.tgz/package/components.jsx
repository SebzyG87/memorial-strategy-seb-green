import React, { useEffect, useState } from "react";

const HUB_URL = "https://work.withsebgreen.com";

function MenuIcon({ open }) {
  return open ? (
    <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20">
      <path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20">
      <path d="M4 7h16M4 12h16M4 17h16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function SebSiteHeader({
  siteName,
  links = [],
  accent = "#7c3aed",
  hubHref = HUB_URL,
  homeHref = "/",
  cta,
  actionText = "#08090d",
}) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const close = (event) => event.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, []);

  return (
    <header data-seb-site-header style={{ "--seb-site-accent": accent, "--seb-site-action-text": actionText }}>
      <div className="seb-site-header__bar">
        <a className="seb-site-header__hub" href={hubHref} aria-label="Return to the Work With Seb Green Hub">
          <span aria-hidden="true">←</span>
          <span>Hub</span>
        </a>

        <a className="seb-site-header__title" href={homeHref} aria-label={`${siteName} home`}>
          {siteName}
        </a>

        <nav className="seb-site-header__desktop" aria-label="Primary website navigation">
          {links.map((link) => (
            <a key={`${link.href}-${link.label}`} href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined}>
              {link.label}
            </a>
          ))}
          {cta ? <a data-seb-site-action="primary" href={cta.href}>{cta.label}</a> : null}
        </nav>

        <button
          className="seb-site-header__toggle"
          type="button"
          aria-label={open ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <MenuIcon open={open} />
        </button>
      </div>

      {open ? (
        <nav className="seb-site-header__mobile" aria-label="Mobile website navigation">
          {links.map((link) => (
            <a key={`${link.href}-${link.label}`} href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined} onClick={() => setOpen(false)}>
              {link.label}
            </a>
          ))}
          {cta ? <a data-seb-site-action="primary" href={cta.href} onClick={() => setOpen(false)}>{cta.label}</a> : null}
        </nav>
      ) : null}
    </header>
  );
}

export function SebSiteFooter({
  siteName,
  descriptor,
  accent = "#7c3aed",
  hubHref = HUB_URL,
  email = "workwithsebgreen@gmail.com",
  phone = "+447903325057",
  links = [],
}) {
  return (
    <footer data-seb-site-footer style={{ "--seb-site-accent": accent }}>
      <div className="seb-site-footer__inner">
        <div className="seb-site-footer__identity">
          <strong>{siteName}</strong>
          {descriptor ? <p>{descriptor}</p> : null}
        </div>
        <nav className="seb-site-footer__links" aria-label={`${siteName} footer navigation`}>
          <a href={hubHref}>All services</a>
          <a href={`mailto:${email}`}>Email</a>
          {phone ? <a href={`tel:${phone}`}>Call</a> : null}
          {links.map((link) => (
            <a key={`${link.href}-${link.label}`} href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined}>
              {link.label}
            </a>
          ))}
        </nav>
        <p className="seb-site-footer__legal">© {new Date().getFullYear()} Seb Green. All rights reserved.</p>
      </div>
    </footer>
  );
}
