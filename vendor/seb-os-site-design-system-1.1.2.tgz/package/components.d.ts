import type { CSSProperties, ReactElement } from "react";

export type SebSiteLink = {
  label: string;
  href: string;
  external?: boolean;
};

export type SebSiteHeaderProps = {
  siteName: string;
  links?: SebSiteLink[];
  accent?: string;
  hubHref?: string;
  homeHref?: string;
  cta?: SebSiteLink;
  actionText?: string;
};

export type SebSiteFooterProps = {
  siteName: string;
  descriptor?: string;
  accent?: string;
  hubHref?: string;
  email?: string;
  phone?: string;
  links?: SebSiteLink[];
};

export declare function SebSiteHeader(props: SebSiteHeaderProps): ReactElement;
export declare function SebSiteFooter(props: SebSiteFooterProps): ReactElement;
