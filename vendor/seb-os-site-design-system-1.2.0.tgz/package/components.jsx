import React, { useEffect, useState } from "react";

const HUB_URL = "https://work.withsebgreen.com";

function MenuIcon({ open }) {
  return open ? (
    <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20">
      <path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20">
      <path d="M4 7h16M4 12h16M4 17h16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

// In-page anchors ("#pricing") only work on the homepage; elsewhere point them at "/#pricing".
function resolveHref(href) {
  if (typeof window === "undefined" || !href || href[0] !== "#") return href;
  return window.location.pathname === "/" ? href : `/${href}`;
}

export function SebSiteHeader({
  siteName,
  links = [],
  accent = "#7c3aed",
  hubHref = HUB_URL,
  homeHref = "/",
  cta,
  actionText = "#08090d",
}) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const close = (event) => event.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, []);

  return (
    <header data-seb-site-header style={{ "--seb-site-accent": accent, "--seb-site-action-text": actionText }}>
      <div className="seb-site-header__bar">
        <a className="seb-site-header__hub" href={hubHref} aria-label="Return to the Work With Seb Green Hub">
          <span aria-hidden="true">←</span>
          <span>Hub</span>
        </a>

        <a className="seb-site-header__title" href={homeHref} aria-label={`${siteName} home`}>
          {siteName}
        </a>

        <nav className="seb-site-header__desktop" aria-label="Primary website navigation">
          {links.map((link) => (
            <a key={`${link.href}-${link.label}`} href={resolveHref(link.href)} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined}>
              {link.label}
            </a>
          ))}
          {cta ? <a data-seb-site-action="primary" href={resolveHref(cta.href)}>{cta.label}</a> : null}
        </nav>

        <button
          className="seb-site-header__toggle"
          type="button"
          aria-label={open ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <MenuIcon open={open} />
        </button>
      </div>

      {open ? (
        <nav className="seb-site-header__mobile" aria-label="Mobile website navigation">
          {links.map((link) => (
            <a key={`${link.href}-${link.label}`} href={resolveHref(link.href)} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined} onClick={() => setOpen(false)}>
              {link.label}
            </a>
          ))}
          {cta ? <a data-seb-site-action="primary" href={resolveHref(cta.href)} onClick={() => setOpen(false)}>{cta.label}</a> : null}
        </nav>
      ) : null}
    </header>
  );
}

export const SEB_CONTACT = {
  name: "Seb Green",
  phoneDisplay: "07903 325057",
  phone: "+447903325057",
  email: "workwithsebgreen@gmail.com",
  whatsappNumber: "447903325057",
  bookingUrl: "https://calendly.com/workwithsebgreen/30min",
};

export const SEB_SERVICES = [
  { label: "Photography", href: "https://photography.withsebgreen.com" },
  { label: "Videography", href: "https://videography.withsebgreen.com" },
  { label: "Drone Solutions", href: "https://dronesolutions.withsebgreen.com" },
  { label: "360 Virtual Tours", href: "https://360virtualtours.withsebgreen.com" },
  { label: "Streaming Media", href: "https://streamingmedia.withsebgreen.com" },
  { label: "Web Development", href: "https://webdev.withsebgreen.com" },
  { label: "Artist Identity", href: "https://artist-identity.withsebgreen.com" },
  { label: "Broadcast Solutions", href: "https://broadcast-solutions.withsebgreen.com" },
  { label: "Event Experiences", href: "https://event-experiences.withsebgreen.com" },
  { label: "Memorial Strategy", href: "https://memorial-strategy.withsebgreen.com" },
  { label: "Property & Systems", href: "https://property-systems.withsebgreen.com" },
  { label: "Strategic Growth", href: "https://strategicbusiness.withsebgreen.com" },
  { label: "Digital Management", href: "https://digitalmanagement.withsebgreen.com" },
];

export function sebWhatsAppUrl(message) {
  const text = message || "Hi Seb, I found you on your website";
  return `https://wa.me/${SEB_CONTACT.whatsappNumber}?text=${encodeURIComponent(text)}`;
}

const isLegalLink = (link) => /^\/(privacy|terms)(\/|$|-)/i.test(link.href) || /^(privacy|terms)/i.test(link.label);

export function SebSiteFooter({
  siteName,
  descriptor,
  accent = "#7c3aed",
  actionText = "#08090d",
  hubHref = HUB_URL,
  email = SEB_CONTACT.email,
  phone = SEB_CONTACT.phone,
  phoneDisplay = SEB_CONTACT.phoneDisplay,
  links = [],
  whatsappMessage,
  bookingUrl = SEB_CONTACT.bookingUrl,
  reviewUrl,
  privacyHref = "/privacy",
  termsHref = "/terms",
  siteUrl,
  showServices = true,
}) {
  const extraLinks = links.filter((link) => !isLegalLink(link));
  const here = (siteUrl || (typeof window !== "undefined" ? window.location.origin : "")).replace(/\/$/, "");
  const services = SEB_SERVICES.filter((s) => s.href !== here && s.label !== siteName);
  const wa = sebWhatsAppUrl(whatsappMessage || `Hi Seb, I found you on your ${siteName} website`);
  return (
    <footer data-seb-site-footer style={{ "--seb-site-accent": accent, "--seb-site-action-text": actionText }}>
      <div className="seb-site-footer__inner">
        <div className="seb-site-footer__identity">
          <strong>{siteName}</strong>
          {descriptor ? <p>{descriptor}</p> : null}
          <address className="seb-site-footer__contact">
            <span>{SEB_CONTACT.name}</span>
            {phone ? <a href={`tel:${phone}`}>{phoneDisplay}</a> : null}
            <a href={`mailto:${email}`}>{email}</a>
          </address>
        </div>
        <div className="seb-site-footer__actions">
          <a data-seb-site-action="primary" data-seb-book-call href={bookingUrl} target="_blank" rel="noopener noreferrer">Book a call</a>
          <a data-seb-whatsapp href={wa} target="_blank" rel="noopener noreferrer" aria-label={`WhatsApp Seb Green about ${siteName}`}>
            <svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.9 11.9 0 0 0 4.6 4c1.7.7 2.4.8 3.2.7.5-.1 1.5-.6 1.8-1.2.2-.6.2-1.1.1-1.2l-.5-.2Z"/></svg>
            <span>WhatsApp</span>
          </a>
          {reviewUrl ? <a data-seb-review href={reviewUrl} target="_blank" rel="noopener noreferrer">Leave a review</a> : null}
        </div>
        <nav className="seb-site-footer__links" aria-label={`${siteName} footer navigation`}>
          <a href={hubHref}>All services</a>
          {extraLinks.map((link) => (
            <a key={`${link.href}-${link.label}`} href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined}>
              {link.label}
            </a>
          ))}
        </nav>
        {showServices ? (
          <nav className="seb-site-footer__services" aria-label="Other services from Seb Green">
            <span>More from Seb Green:</span>
            {services.map((s) => <a key={s.href} href={s.href}>{s.label}</a>)}
          </nav>
        ) : null}
        <p className="seb-site-footer__legal">
          <span>© {new Date().getFullYear()} Seb Green. All rights reserved.</span>
          <a href={privacyHref}>Privacy</a>
          <a href={termsHref}>Terms</a>
        </p>
      </div>
    </footer>
  );
}

const UPDATED_DEFAULT = "13 November 2026";

function LegalShell({ eyebrow, title, updated, children, as: Tag = "main" }) {
  return (
    <Tag data-seb-legal>
      <p className="seb-legal__eyebrow">{eyebrow}</p>
      <h1>{title}</h1>
      <p className="seb-legal__updated">Last updated {updated}</p>
      {children}
      <p className="seb-legal__back"><a href="/">← Back to {eyebrow}</a></p>
    </Tag>
  );
}

function ContactLine() {
  return (
    <p>
      Email <a href={`mailto:${SEB_CONTACT.email}`}>{SEB_CONTACT.email}</a>, call{" "}
      <a href={`tel:${SEB_CONTACT.phone}`}>{SEB_CONTACT.phoneDisplay}</a> or message on{" "}
      <a href={sebWhatsAppUrl()} target="_blank" rel="noopener noreferrer">WhatsApp</a>.
    </p>
  );
}

export function SebPrivacyPolicy({ siteName, hasEnquiryForm = false, updated = UPDATED_DEFAULT, extra = null, as }) {
  return (
    <LegalShell eyebrow={siteName} title="Privacy Policy" updated={updated} as={as}>
      <section>
        <h2>Who we are</h2>
        <p>This website is run by Seb Green, trading as {siteName} under the With Seb Green brand. Seb Green is responsible for the personal information you share through this site.</p>
      </section>
      <section>
        <h2>What we collect and why</h2>
        <ul>
          {hasEnquiryForm ? (
            <li><strong>Enquiry and feedback forms.</strong> Your name, email address, the service you are interested in and your message (or, for feedback, your rating, comment and optional email). These are stored securely in our database (Supabase) so we can reply. Seb may also receive an email copy, and you may receive an automatic confirmation email.</li>
          ) : null}
          <li><strong>Email, phone and WhatsApp.</strong> If you contact us directly, we receive whatever you choose to send. WhatsApp messages are handled by WhatsApp (Meta) under its own privacy policy.</li>
          <li><strong>Booking a call.</strong> Calls are booked through Calendly, which collects the details you enter there under its own privacy policy.</li>
          <li><strong>Payments.</strong> If you pay a deposit or fee online, payment is handled by Stripe. We never see or store your card details.</li>
          <li><strong>Analytics.</strong> We use Vercel Web Analytics to count page views. It does not use cookies and does not identify you personally.</li>
          <li><strong>Hosting.</strong> Our host (Vercel) keeps standard technical logs, such as IP address and browser type, to run and protect the site.</li>
        </ul>
      </section>
      <section>
        <h2>Cookies</h2>
        <p>This site does not set advertising or tracking cookies, so there is no cookie banner.{hasEnquiryForm ? " The forms remember in your browser when you last sent a message, only to stop accidental repeat sends." : ""} Linked services (such as Calendly, Stripe or WhatsApp) may set their own cookies when you use them.</p>
      </section>
      <section>
        <h2>How long we keep it</h2>
        <p>Enquiries are kept for as long as needed to answer them and for any follow-up work. Records linked to paid work are kept for as long as the law requires for tax and accounting.</p>
      </section>
      <section>
        <h2>Your rights</h2>
        <p>Under UK data protection law you can ask to see, correct or delete the personal information we hold about you, or object to how we use it. You can also complain to the Information Commissioner's Office at <a href="https://ico.org.uk" target="_blank" rel="noopener noreferrer">ico.org.uk</a>.</p>
      </section>
      {extra}
      <section>
        <h2>Contact</h2>
        <ContactLine />
      </section>
    </LegalShell>
  );
}

export function SebTermsOfService({ siteName, updated = UPDATED_DEFAULT, extra = null, as }) {
  return (
    <LegalShell eyebrow={siteName} title="Terms of Service" updated={updated} as={as}>
      <section>
        <h2>About these terms</h2>
        <p>These terms apply when you book services from Seb Green through {siteName}. Anything agreed with you in writing for a specific job also applies.</p>
      </section>
      <section>
        <h2>Quotes and prices</h2>
        <p>Prices on this site are current published prices, and "from" prices are starting points. Your final scope and price are confirmed in writing before work starts.</p>
      </section>
      <section>
        <h2>Deposits and payment</h2>
        <p>Some services can be secured with a deposit paid online through Stripe. Deposit amounts, payment dates and what happens if plans change are confirmed in writing when you book.</p>
      </section>
      <section>
        <h2>Insurance</h2>
        <p>Where a job needs it, insurance is arranged for that job.</p>
      </section>
      <section>
        <h2>Your content and permissions</h2>
        <p>You confirm you have permission for any location, people or material you ask us to capture or use. We will only show your work in our portfolio if you agree.</p>
      </section>
      <section>
        <h2>Liability</h2>
        <p>We take reasonable care in all work. We are not responsible for losses caused by third-party platforms or by events outside our control.</p>
      </section>
      {extra}
      <section>
        <h2>Contact</h2>
        <ContactLine />
      </section>
    </LegalShell>
  );
}
