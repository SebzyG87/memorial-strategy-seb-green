import type { CSSProperties, ReactElement, ReactNode } from "react";

export type SebSiteLink = {
  label: string;
  href: string;
  external?: boolean;
};

export type SebSiteHeaderProps = {
  siteName: string;
  links?: SebSiteLink[];
  accent?: string;
  hubHref?: string;
  homeHref?: string;
  cta?: SebSiteLink;
  actionText?: string;
};

export type SebSiteFooterProps = {
  siteName: string;
  descriptor?: string;
  accent?: string;
  actionText?: string;
  hubHref?: string;
  email?: string;
  phone?: string;
  phoneDisplay?: string;
  links?: SebSiteLink[];
  /** Prefilled WhatsApp message. Defaults to "Hi Seb, I found you on your <siteName> website". */
  whatsappMessage?: string;
  /** Calendly event for "Book a call". Defaults to calendly.com/workwithsebgreen/30min. */
  bookingUrl?: string;
  /** Google review URL. The "Leave a review" link is hidden when empty. */
  reviewUrl?: string;
  privacyHref?: string;
  termsHref?: string;
  /** This site's live origin, used to leave it out of "More from Seb Green". */
  siteUrl?: string;
  showServices?: boolean;
};

export type SebLegalProps = {
  siteName: string;
  updated?: string;
  extra?: ReactNode;
  /** Wrapper element. Use "article" when the page already has a <main>. */
  as?: "main" | "article" | "section" | "div";
};

export declare const SEB_CONTACT: {
  name: string;
  phoneDisplay: string;
  phone: string;
  email: string;
  whatsappNumber: string;
  bookingUrl: string;
};
export declare const SEB_SERVICES: SebSiteLink[];
export declare function sebWhatsAppUrl(message?: string): string;
export declare function SebPrivacyPolicy(props: SebLegalProps & { hasEnquiryForm?: boolean }): ReactElement;
export declare function SebTermsOfService(props: SebLegalProps): ReactElement;

export declare function SebSiteHeader(props: SebSiteHeaderProps): ReactElement;
export declare function SebSiteFooter(props: SebSiteFooterProps): ReactElement;
